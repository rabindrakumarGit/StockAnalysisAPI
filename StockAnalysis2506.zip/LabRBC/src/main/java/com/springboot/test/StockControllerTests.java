package com.springboot.test;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.springboot.Stock;
import com.springboot.StockController;
import com.springboot.StockRepository;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

public class StockControllerTests {

    @Mock
    private StockRepository stockRepository;

    @InjectMocks
    private StockController stockController;
@Mock
    private MockMvc mockMvc;

    @Test
    public void testGetAllStocks() throws Exception {
        // Mock data
        Stock stock1 = new Stock("Apple", 10);
        Stock stock2 = new Stock("Banana", 20);
        List<Stock> stocks = Arrays.asList(stock1, stock2);

        // Mock repository method
        when(stockRepository.findAll()).thenReturn(stocks);

        // Setup mockMvc
        mockMvc = standaloneSetup(stockController).build();

        // Perform GET request and verify
        mockMvc.perform(MockMvcRequestBuilders.get("/api/stocks")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("[{\"id\":1,\"name\":\"Apple\",\"quantity\":10},{\"id\":2,\"name\":\"Banana\",\"quantity\":20}]"));
    }
    @Test
    public void testCreateStock() throws Exception {
        Stock newStock = new Stock("Orange", 15);

        // Mock repository save method
        when(stockRepository.save(newStock)).thenReturn(newStock);

        // Setup mockMvc
        mockMvc = standaloneSetup(stockController).build();

        // Perform POST request and verify
        mockMvc.perform(MockMvcRequestBuilders.post("/api/stocks")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Orange\",\"quantity\":15}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Orange"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.quantity").value(15));
    }
    @Test
    public void testGetStockById() throws Exception {
        Stock stock = new Stock("Apple", 10);

        // Mock repository findById method
        when(stockRepository.findById(1L)).thenReturn(java.util.Optional.of(stock));

        // Setup mockMvc
        mockMvc = standaloneSetup(stockController).build();

        // Perform GET request and verify
        mockMvc.perform(MockMvcRequestBuilders.get("/api/stocks/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Apple"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.quantity").value(10));
    }
    @Test
    public void testUpdateStock() throws Exception {
        Stock existingStock = new Stock("Apple", 10);
        Stock updatedStock = new Stock("Apple", 20);

        // Mock repository findById and save methods
        when(stockRepository.findById(1L)).thenReturn(java.util.Optional.of(existingStock));
        when(stockRepository.save(existingStock)).thenReturn(updatedStock);

        // Setup mockMvc
        mockMvc = standaloneSetup(stockController).build();

        // Perform PUT request and verify
        mockMvc.perform(MockMvcRequestBuilders.put("/api/stocks/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Apple\",\"quantity\":20}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.quantity").value(20));
    }
    @Test
    public void testDeleteStock() throws Exception {
        Stock stockToDelete = new Stock("Apple", 10);

        // Mock repository findById and delete methods
        when(stockRepository.findById(1L)).thenReturn(java.util.Optional.of(stockToDelete));

        // Setup mockMvc
        mockMvc = standaloneSetup(stockController).build();

        // Perform DELETE request and verify
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/stocks/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }



}

