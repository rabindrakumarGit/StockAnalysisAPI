package com.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stocks")
public class StockController {
    
    @Autowired
    private StockRepository stockRepository;
    
    @GetMapping
    public List<Stock> getAllStocks() {
        return stockRepository.findAll();
    }
    
    @PostMapping
    public Stock createStock(@RequestBody Stock stock) {
        return stockRepository.save(stock);
    }
    
    @GetMapping("/{id}")
    public Stock getStockById(@PathVariable Long id) {
        return stockRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stock not found with id " + id));
    }
    
    @PutMapping("/{id}")
    public Stock updateStock(@PathVariable Long id, @RequestBody Stock updatedStock) {
        Stock stock = stockRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stock not found with id " + id));
        
        stock.setName(updatedStock.getName());
        stock.setQuantity(updatedStock.getQuantity());
        
        return stockRepository.save(stock);
    }
    
    @DeleteMapping("/{id}")
    public void deleteStock(@PathVariable Long id) {
        Stock stock = stockRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stock not found with id " + id));
        
        stockRepository.delete(stock);
    }
}
